=== Memolane Embed ===
Contributors: tribalvibes
Donate link: http://memolane.com/
Tags: Memolane, media embedding, timeline view
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: 3.1

Embed the awesome Memolane media timeline view via an easy WordPress shortcode plugin.


== Description ==

This WordPress plugin adds a simple shortcode to embed the awesome Memolane media timeline view in your blog posts.

When adding a post with a Memolane embed, first switch from the Visual to the HTML tab of the post editor. Then, add the shortcode [memolane] where you want the Memloane view to appear.

To embed the Memolane lane with all the default settings, use the shortcode:
[memolane]

But you probably want to at least specify a lane, like this (otherwise you'll just get ours!):
[memolane lane="mylanename"]

The following parameters are available:
[memolane lane="mylanename" width="450" height="600" background="#000044" border="1px solid #9AF"]

For more information, refer to:
http://blog.memolane.com/post/4719158195/one-lane-two-lanes-red-lanes-blue-lanes-embedded


== Installation ==

1. Unzip `memolane.zip` and place the resulting folder, or just the contained `memolane.php` file, in the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress (in the left bar)
3. Start using the shortcode (by following the directions outlined in the description)!


== Changelog ==

= 0.01 =
* Initial version